playergravity = 400

_MAPNAMES =
{
	"Network of MyPC95",
	"Triple bass",
	"Climb or swim",
	"2spooky4me",
	"Splish Splash",
	"Smile.jpg",
	"Where sleeping docs lie"
}

playerhealth = 5

